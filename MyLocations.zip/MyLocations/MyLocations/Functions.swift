//
//  Functions.swift
//  MyLocations
//
//  Created by user186046 on 2/26/21.
//  Copyright © 2021 MorsWolfProductions. All rights reserved.
//

import Foundation

func afterDelay(_ seconds: Double, run: @escaping () -> Void) {
 DispatchQueue.main.asyncAfter(deadline: .now() + seconds,
 execute: run)
}
