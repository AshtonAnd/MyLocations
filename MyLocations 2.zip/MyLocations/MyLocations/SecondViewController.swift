//
//  SecondViewController.swift
//  MyLocations
//
//  Created by user186046 on 2/13/21.
//  Copyright © 2021 MorsWolfProductions. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

