//
//  Location+CoreDataClass.swift
//  MyLocations
//
//  Created by user186046 on 2/26/21.
//  Copyright © 2021 MorsWolfProductions. All rights reserved.
//
//

import Foundation
import CoreData

@objc(Location)
public class Location: NSManagedObject {

}
