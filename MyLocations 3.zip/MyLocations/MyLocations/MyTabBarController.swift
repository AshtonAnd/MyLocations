//
//  MyTabBarController.swift
//  MyLocations
//
//  Created by user186046 on 2/27/21.
//  Copyright © 2021 MorsWolfProductions. All rights reserved.
//

import UIKit
class MyTabBarController: UITabBarController {
 override var preferredStatusBarStyle: UIStatusBarStyle {
 return .lightContent
 }

 override var childForStatusBarStyle: UIViewController? {
 return nil
 }
}
