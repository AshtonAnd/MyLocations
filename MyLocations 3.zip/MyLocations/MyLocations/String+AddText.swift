//
//  String+AddText.swift
//  MyLocations
//
//  Created by user186046 on 2/27/21.
//  Copyright © 2021 MorsWolfProductions. All rights reserved.
//

import Foundation

extension String {
mutating func add(text: String?,
 separatedBy separator: String = "") { if let text = text {
 if !isEmpty {
 self += separator
 }
 self += text
 }
 }
}
